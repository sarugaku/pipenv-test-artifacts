class ParserError(ValueError):

    pass
