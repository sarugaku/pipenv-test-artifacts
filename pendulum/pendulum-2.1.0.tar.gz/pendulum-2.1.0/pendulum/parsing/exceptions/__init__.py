class ParserError(ValueError):

    pass
