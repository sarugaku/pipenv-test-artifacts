from .application import Application


def main():
    return Application().run()
