class InvalidVersion(ValueError):

    pass
