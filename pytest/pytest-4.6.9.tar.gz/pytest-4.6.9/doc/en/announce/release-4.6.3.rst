pytest-4.6.3
=======================================

pytest 4.6.3 has just been released to PyPI.

This is a bug-fix release, being a drop-in replacement. To upgrade::

  pip install --upgrade pytest

The full changelog is available at https://docs.pytest.org/en/latest/changelog.html.

Thanks to all who contributed to this release, among them:

* Anthony Sottile
* Bruno Oliveira
* Daniel Hahler
* Dirk Thomas


Happy testing,
The pytest Development Team
