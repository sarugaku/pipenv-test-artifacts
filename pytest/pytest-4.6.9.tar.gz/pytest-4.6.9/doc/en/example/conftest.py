# -*- coding: utf-8 -*-
collect_ignore = ["nonpython"]
